# Fairview Bedding – Free E-commerce Website

This version includes 3 new product images:
- Printed Bedsheet with Pillow Covers
- White Ruffle Bed Skirt
- White Ruffle Cushion Cover

The three new products are set to **Price on Request** until you add your actual prices.

## GitHub Pages
1. Create a public repository named `fairview-bedding`.
2. Upload all files in this folder to the repository root.
3. Go to Settings → Pages.
4. Select Deploy from a branch → `main` → `/ (root)` → Save.
5. Your site will be available at `https://YOUR-USERNAME.github.io/fairview-bedding/`.

## Product images
Keep `product1.jpg`, `product2.jpg`, and `product3.jpg` in the same folder as `index.html`.
